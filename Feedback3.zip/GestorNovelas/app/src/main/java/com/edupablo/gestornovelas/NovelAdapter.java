package com.edupablo.gestornovelas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class NovelAdapter extends RecyclerView.Adapter<NovelAdapter.NovelViewHolder> {
    private List<Novel> novels = new ArrayList<>(); // Inicializamos la lista vacía para evitar null

    // Método para establecer la lista completa de novelas (ej. al cargar desde Firestore)
    public void setNovels(List<Novel> novels) {
        this.novels = novels;
        notifyDataSetChanged(); // Notifica al adapter que los datos han cambiado
    }

    // Método para agregar una nueva novela y actualizar el RecyclerView
    public void addNovel(Novel novel) {
        this.novels.add(novel);  // Añadir la nueva novela a la lista
        notifyItemInserted(novels.size() - 1);  // Notifica al adapter del nuevo elemento
    }

    @NonNull
    @Override
    public NovelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos un layout personalizado para cada ítem de la lista
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.novel_item, parent, false);  // Reemplazamos el layout simple por uno personalizado
        return new NovelViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NovelViewHolder holder, int position) {
        // Vinculamos los datos de la novela con las vistas
        Novel currentNovel = novels.get(position);
        holder.titleTextView.setText(currentNovel.getTitle());
        holder.authorTextView.setText(currentNovel.getAuthor());
       }

    @Override
    public int getItemCount() {
        return novels == null ? 0 : novels.size();
    }

    static class NovelViewHolder extends RecyclerView.ViewHolder {
        private final TextView titleTextView;
        private final TextView authorTextView;

        private NovelViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.textViewTitle);  // Asegúrate de tener estas referencias en tu layout
            authorTextView = itemView.findViewById(R.id.textViewAuthor);
           }
    }
}
