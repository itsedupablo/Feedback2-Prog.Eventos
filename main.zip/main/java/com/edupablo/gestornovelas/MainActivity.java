package com.edupablo.gestornovelas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button buttonAndBook;
    private RecyclerView recyclerView;
    private NovelViewModel novelViewModel;
    private NovelAdapter novelAdapter;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db; // Firestore

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar Firebase Auth y Firestore
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();  // Inicializar Firestore

        // Referencias a los elementos del layout
        buttonAndBook = findViewById(R.id.buttonAndBook);
        recyclerView = findViewById(R.id.recyclerView);

        // Configurar el RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        novelAdapter = new NovelAdapter();
        recyclerView.setAdapter(novelAdapter);

        // Obtener ViewModel
        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);

        novelViewModel.getAllNovels().observe(this, new Observer<List<Novel>>() {
            @Override
            public void onChanged(List<Novel> novels) {
                novelAdapter.setNovels(novels);
            }
        });

        // Verificar si el usuario está autenticado
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            buttonAndBook.setVisibility(View.GONE);
        } else {
            buttonAndBook.setVisibility(View.VISIBLE);
        }

        // Botón para agregar una novela
        buttonAndBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddNovelDialog();
            }
        });

        // Leer las novelas desde Firestore
        getNovelsFromFirestore();

        // Ejecutar LongRunningTask
        new LongRunningTask(this).execute();
    }

    // Método para mostrar el diálogo de agregar novela
    private void showAddNovelDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.agregar_novela_dialog, null);
        builder.setView(dialogView);

        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextAuthor = dialogView.findViewById(R.id.editTextAuthor);
        EditText editTextYear = dialogView.findViewById(R.id.editTextYear);
        EditText editTextSynopsis = dialogView.findViewById(R.id.editTextSynopsis);

        builder.setTitle("Add Novel")
                .setPositiveButton("Add", (dialog, which) -> {
                    String title = editTextTitle.getText().toString();
                    String author = editTextAuthor.getText().toString();
                    int year = Integer.parseInt(editTextYear.getText().toString());
                    String synopsis = editTextSynopsis.getText().toString();
                    addNovel(title, author, year, synopsis);
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Método para agregar una novela a Firestore
    private void addNovel(String title, String author, int year, String synopsis) {
        Map<String, Object> novel = new HashMap<>();
        novel.put("title", title);
        novel.put("author", author);
        novel.put("year", year);
        novel.put("synopsis", synopsis);

        // Añadir la novela a Firestore
        db.collection("novels")
                .add(novel)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(MainActivity.this, "Novela añadida con ID: " + documentReference.getId(), Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity.this, "Error al añadir novela", Toast.LENGTH_SHORT).show();
                });
    }

    // Método para leer las novelas desde Firestore
    private void getNovelsFromFirestore() {
        db.collection("novels")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Novel novel = document.toObject(Novel.class);
                                novelAdapter.addNovel(novel); // Añadir novela al RecyclerView
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Error al obtener novelas", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}