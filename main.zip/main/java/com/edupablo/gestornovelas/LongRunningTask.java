package com.edupablo.gestornovelas;

import android.os.AsyncTask;
import android.widget.Toast;

public class LongRunningTask extends AsyncTask<Void, Void, String> {

    private MainActivity activity;

    public LongRunningTask(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    protected String doInBackground(Void... voids) {
        // Perform long-running operation here
        // For example, a network request or database operation
        try {
            Thread.sleep(5000); // Simulate long-running operation
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "Operation Completed";
    }

    @Override
    protected void onPostExecute(String result) {
        // Update UI with the result
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }
}