package com.edupablo.gestornovelas;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class NovelAdapter extends RecyclerView.Adapter<NovelAdapter.NovelViewHolder> {

    private List<Novel> novels = new ArrayList<>();

    // Método para establecer la lista completa de novelas
    @SuppressLint("NotifyDataSetChanged")
    public void setNovels(List<Novel> novels) {
        this.novels = novels;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public NovelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.novel_item, parent, false);
        return new NovelViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NovelViewHolder holder, int position) {
        Novel currentNovel = novels.get(position);
        holder.titleTextView.setText(currentNovel.getTitle());
        holder.authorTextView.setText(currentNovel.getAuthor());

        // Establece el listener para el menú contextual
        holder.itemView.setOnClickListener(view -> showPopupMenu(view, currentNovel, position));
    }

    @Override
    public int getItemCount() {
        return novels == null ? 0 : novels.size();
    }

    // Muestra el menú contextual con opciones
    private void showPopupMenu(View view, Novel novel, int position) {
        PopupMenu popup = new PopupMenu(view.getContext(), view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menu_novelas, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> handleMenuItemClick(item, novel, position, view));
        popup.show();
    }

    // Maneja las opciones seleccionadas en el menú contextual
    private boolean handleMenuItemClick(MenuItem item, Novel novel, int position, View view) {
        if (item.getItemId() == R.id.action_view_details) {
            // Acción: Mostrar detalles en un fragmento
            AppCompatActivity activity = (AppCompatActivity) view.getContext();
            NovelDetailFragment fragment = NovelDetailFragment.newInstance(
                    novel.getTitle(),
                    novel.getAuthor(),
                    novel.getYear(),
                    novel.getSynopsis()
            );

            // Reemplazar el contenido del contenedor de fragmentos
            activity.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack(null) // Permitir navegación hacia atrás
                    .commit();

            return true;

        } else if (item.getItemId() == R.id.action_mark_favorite) {
            // Acción: Marcar como favorito
            boolean newFavoriteStatus = !novel.isFavorite(); // Cambiar estado actual
            novel.setFavorite(newFavoriteStatus); // Actualizar el modelo en memoria

            // Actualizar en la base de datos
            NovelViewModel viewModel = new ViewModelProvider((MainActivity) view.getContext())
                    .get(NovelViewModel.class);
            viewModel.updateFavoriteStatus(novel);

            // Mensaje de confirmación
            Toast.makeText(view.getContext(),
                    newFavoriteStatus ? "Añadido a favoritos: " + novel.getTitle()
                            : "Eliminado de favoritos: " + novel.getTitle(),
                    Toast.LENGTH_SHORT).show();
            return true;

        } else if (item.getItemId() == R.id.action_delete) {
            // Acción: Eliminar novela
            novels.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(view.getContext(), "Novela eliminada", Toast.LENGTH_SHORT).show();
            return true;

        } else {
            return false;
        }
    }
    // ViewHolder de la clase Novel
    static class NovelViewHolder extends RecyclerView.ViewHolder {
        private final TextView titleTextView;
        private final TextView authorTextView;

        private NovelViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.textViewTitle);
            authorTextView = itemView.findViewById(R.id.textViewAuthor);
        }
    }
}
