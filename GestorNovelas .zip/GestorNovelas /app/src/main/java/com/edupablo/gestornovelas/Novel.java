package com.edupablo.gestornovelas;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "novel_table")
public class Novel {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String author;
    private int year;
    private String synopsis;
    private boolean favorite;
    private String review;

    public Novel(String title, String author, int year, String synopsis, boolean favorite, String review) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.synopsis = synopsis;
        this.favorite = favorite;
        this.review = review;
    }

    public Novel(String title, String author, int year, String synopsis, boolean isFavorite) {
        this(title, author, year, synopsis, isFavorite, null); // Inicializa review como null por defecto
    }


    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }
    public String getSynopsis() { return synopsis; }
    public boolean isFavorite() { return favorite; }
    public String getReview() { return review; }


    public void setId(int id) { this.id = id; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
    public void setReview(String review) { this.review = review; }
}

