package com.edupablo.gestornovelas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

public class FavoritesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NovelAdapter novelAdapter;
    private NovelViewModel novelViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        recyclerView = findViewById(R.id.recyclerViewFavorites);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        novelAdapter = new NovelAdapter();
        recyclerView.setAdapter(novelAdapter);

        // Configuración de ViewModel para observar solo las novelas favoritas
        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);
        novelViewModel.getFavoriteNovels().observe(this, favorites -> {
            if (favorites != null && !favorites.isEmpty()) {
                novelAdapter.setNovels(favorites);  // Actualiza el adapter con los favoritos
            } else {
                // En caso de que no haya favoritos, muestra un mensaje o realiza alguna acción
                Toast.makeText(this, "No hay novelas favoritas", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
