package com.edupablo.gestornovelas;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;


import java.util.List;

public class FavoritesWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new FavoritesRemoteViewsFactory(getApplicationContext());
    }
}

class FavoritesRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {
    private final Context context;
    private List<Novel> favoriteNovels;

    public FavoritesRemoteViewsFactory(Context context) {
        this.context = context;
    }

    @Override
    public void onCreate() {
        // Cargar favoritos
        loadFavorites();
    }

    @Override
    public void onDataSetChanged() {
        // Recargar favoritos cuando sea necesario
        loadFavorites();
    }

    private void loadFavorites() {
        // Obtener las novelas favoritas (usar ViewModel o base de datos según tu implementación)
        NovelDatabase db = NovelDatabase.getInstance(context);
        favoriteNovels = db.novelDao().getFavoriteNovels().getValue();
    }

    @Override
    public int getCount() {
        return favoriteNovels == null ? 0 : favoriteNovels.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        if (favoriteNovels == null || favoriteNovels.size() <= position) return null;

        Novel novel = favoriteNovels.get(position);
        RemoteViews views = new RemoteViews(context.getPackageName(), android.R.layout.simple_list_item_1);
        views.setTextViewText(android.R.id.text1, novel.getTitle());

        Intent fillInIntent = new Intent();
        fillInIntent.putExtra("novel_id", novel.getId());
        views.setOnClickFillInIntent(android.R.id.text1, fillInIntent);

        return views;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public void onDestroy() {
        favoriteNovels = null;
    }
}
