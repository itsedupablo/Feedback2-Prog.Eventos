package com.edupablo.gestornovelas;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NovelDao {
    @Insert
    void insert(Novel novel);

    @Delete
    void delete(Novel novel);

    @Query("SELECT * FROM novel_table ORDER BY title ASC")
    LiveData<List<Novel>> getAllNovels();

    @Query("SELECT * FROM novel_table WHERE favorite = 1")  // Asegúrate de que esté en 1 para favoritos
    LiveData<List<Novel>> getFavoriteNovels();

    @Query("UPDATE novel_table SET favorite = :isFavorite WHERE id = :id")
    void updateFavoriteStatus(int id, boolean isFavorite);

    @Query("SELECT * FROM novel_table WHERE id = :id LIMIT 1")
    Novel getNovelById(int id);

    @Update
    void update(Novel novel);


}


