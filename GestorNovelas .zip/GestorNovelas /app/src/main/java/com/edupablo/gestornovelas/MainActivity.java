package com.edupablo.gestornovelas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private Button buttonAddBook;
    private Button buttonViewFavorites; // Botón "Ver favoritos"
    private RecyclerView recyclerView;
    private NovelViewModel novelViewModel;
    private NovelAdapter novelAdapter;
    private boolean showingFavorites = false; // Control para mostrar favoritos o todas las novelas

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAddBook = findViewById(R.id.buttonAddBook);
        buttonViewFavorites = findViewById(R.id.buttonViewFavorites); // Inicializamos el botón de favoritos
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        novelAdapter = new NovelAdapter();
        recyclerView.setAdapter(novelAdapter);

        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);

        // Observa todas las novelas para mostrar en el RecyclerView
        novelViewModel.getAllNovels().observe(this, novels -> {
            if (!showingFavorites) {
                novelAdapter.setNovels(novels);
            }
        });

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        buttonAddBook.setVisibility(currentUser != null ? View.VISIBLE : View.GONE);

        buttonAddBook.setOnClickListener(v -> showAddNovelDialog());

        // Listener para el botón "Ver favoritos"
        buttonViewFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
            startActivity(intent);
        });

    }

    // Método para alternar entre mostrar todos y solo los favoritos
    private void toggleFavorites() {
        showingFavorites = !showingFavorites;

        if (showingFavorites) {
            novelViewModel.getFavoriteNovels().observe(this, favorites -> {
                novelAdapter.setNovels(favorites);
                Toast.makeText(this, "Mostrando favoritos", Toast.LENGTH_SHORT).show();
            });
            buttonViewFavorites.setText("Ver todos");
        } else {
            novelViewModel.getAllNovels().observe(this, novels -> novelAdapter.setNovels(novels));
            buttonViewFavorites.setText("Ver favoritos");
        }
    }

    private void showAddNovelDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.agregar_novela_dialog, null);
        builder.setView(dialogView);

        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextAuthor = dialogView.findViewById(R.id.editTextAuthor);
        EditText editTextYear = dialogView.findViewById(R.id.editTextYear);
        EditText editTextSynopsis = dialogView.findViewById(R.id.editTextSynopsis);

        builder.setTitle("Add Novel")
                .setPositiveButton("Add", (dialog, which) -> {
                    String title = editTextTitle.getText().toString();
                    String author = editTextAuthor.getText().toString();
                    int year = Integer.parseInt(editTextYear.getText().toString());
                    String synopsis = editTextSynopsis.getText().toString();

                    Novel novel = new Novel(title, author, year, synopsis, false);
                    novelViewModel.insert(novel);

                    Toast.makeText(this, "Novel added", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
