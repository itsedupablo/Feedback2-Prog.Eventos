package com.edupablo.gestornovelas;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NovelViewModel extends AndroidViewModel {
    private final NovelRepository repository;
    private final LiveData<List<Novel>> allNovels;
    private final ExecutorService executorService;

    public NovelViewModel(@NonNull Application application) {
        super(application);
        repository = new NovelRepository(application);
        allNovels = repository.getAllNovels();
        executorService = Executors.newSingleThreadExecutor(); // Inicializamos el ejecutor
    }

    public LiveData<List<Novel>> getAllNovels() {
        return allNovels;
    }

    public LiveData<List<Novel>> getFavoriteNovels() {
        return repository.getFavoriteNovels(); // Acceso correcto al método
    }

    public void insert(Novel novel) {
        repository.insert(novel);
    }

    public void delete(Novel novel) {
        repository.delete(novel);
    }

    public void updateFavoriteStatus(Novel novel) {
        repository.updateFavoriteStatus(novel);
    }

    public void addReview(int novelId, String review) {
        executorService.execute(() -> {
            Novel novel = repository.getNovelById(novelId); // Accede al DAO a través del repositorio
            if (novel != null) {
                novel.setReview(review);
                repository.update(novel); // Actualizamos usando el repositorio
            }
        });
    }
}
