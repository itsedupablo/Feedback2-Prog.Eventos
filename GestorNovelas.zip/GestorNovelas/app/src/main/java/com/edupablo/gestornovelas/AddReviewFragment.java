package com.edupablo.gestornovelas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

public class AddReviewFragment extends Fragment {

    private static final String ARG_NOVEL_ID = "novel_id";
    private int novelId;
    private NovelViewModel novelViewModel;

    public static AddReviewFragment newInstance(int novelId) {
        AddReviewFragment fragment = new AddReviewFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_NOVEL_ID, novelId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            novelId = getArguments().getInt(ARG_NOVEL_ID);
        }
        novelViewModel = new ViewModelProvider(requireActivity()).get(NovelViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_review, container, false);

        EditText editTextReview = view.findViewById(R.id.editTextReview);
        Button buttonSubmitReview = view.findViewById(R.id.buttonSubmitReview);

        buttonSubmitReview.setOnClickListener(v -> {
            String reviewText = editTextReview.getText().toString().trim();
            if (reviewText.isEmpty()) {
                Toast.makeText(getContext(), "La reseña no puede estar vacía", Toast.LENGTH_SHORT).show();
                return;
            }

            // Guardar la reseña en la base de datos
            novelViewModel.addReview(novelId, reviewText);

            Toast.makeText(getContext(), "Reseña añadida con éxito", Toast.LENGTH_SHORT).show();
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
