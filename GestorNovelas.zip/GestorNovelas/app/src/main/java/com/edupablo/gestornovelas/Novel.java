package com.edupablo.gestornovelas;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "novel_table")
public class Novel {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String author;
    private int year;
    private String synopsis;
    private boolean favorite;
    private String review;
    private double latitude;
    private double longitude;

    // Constructor principal
    public Novel(String title, String author, int year, String synopsis, boolean favorite, String review, double latitude, double longitude) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.synopsis = synopsis;
        this.favorite = favorite;
        this.review = review;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Constructor con valores predeterminados para latitud, longitud y review
    public Novel(String title, String author, int year, String synopsis, boolean isFavorite) {
        this(title, author, year, synopsis, isFavorite, null, 0, 0); // Inicializa review como null y ubicación como (0, 0)
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }
    public String getSynopsis() { return synopsis; }
    public boolean isFavorite() { return favorite; }
    public String getReview() { return review; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
    public void setReview(String review) { this.review = review; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
}
