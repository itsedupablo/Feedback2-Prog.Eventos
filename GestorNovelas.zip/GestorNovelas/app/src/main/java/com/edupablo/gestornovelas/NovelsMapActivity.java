package com.edupablo.gestornovelas;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import org.osmdroid.config.Configuration;
import org.osmdroid.library.BuildConfig;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.util.List;

public class NovelsMapActivity extends AppCompatActivity {

    private MapView mapView;
    private NovelViewModel novelViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configurar OSMDroid
        Configuration.getInstance().setUserAgentValue(BuildConfig.APPLICATION_ID);

        setContentView(R.layout.activity_novels_map);

        // Inicializar el MapView
        mapView = findViewById(R.id.mapView);
        mapView.setTileSource(TileSourceFactory.MAPNIK);  // Usar OpenStreetMap
        mapView.setMultiTouchControls(true);
        mapView.setBuiltInZoomControls(true);

        // Inicializar el ViewModel
        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);

        // Obtener las novelas y mostrarlas en el mapa
        novelViewModel.getAllNovels().observe(this, novels -> {
            if (novels != null && !novels.isEmpty()) {
                showNovelsOnMap(novels);
            } else {
                Toast.makeText(this, "No hay novelas para mostrar en el mapa", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showNovelsOnMap(List<Novel> novels) {
        // Agregar un marcador para cada novela
        for (Novel novel : novels) {
            if (novel.getLatitude() != 0 && novel.getLongitude() != 0) {
                GeoPoint geoPoint = new GeoPoint(novel.getLatitude(), novel.getLongitude());

                Marker marker = new Marker(mapView);
                marker.setPosition(geoPoint);
                marker.setTitle(novel.getTitle());
                marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);

                mapView.getOverlays().add(marker);
            }
        }

        // Ajustar el mapa para mostrar todos los marcadores
        mapView.zoomToBoundingBox(mapView.getBoundingBox(), true);
    }
}
