package com.edupablo.gestornovelas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class NovelDetailFragment extends Fragment {

    private static final String ARG_TITLE = "title";
    private static final String ARG_AUTHOR = "author";
    private static final String ARG_YEAR = "year";
    private static final String ARG_SYNOPSIS = "synopsis";

    public static NovelDetailFragment newInstance(String title, String author, int year, String synopsis) {
        NovelDetailFragment fragment = new NovelDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putString(ARG_AUTHOR, author);
        args.putInt(ARG_YEAR, year);
        args.putString(ARG_SYNOPSIS, synopsis);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_novel_detail, container, false);

        // Obtener los argumentos
        Bundle args = getArguments();
        if (args != null) {
            String title = args.getString(ARG_TITLE);
            String author = args.getString(ARG_AUTHOR);
            int year = args.getInt(ARG_YEAR);
            String synopsis = args.getString(ARG_SYNOPSIS);

            // Configurar los TextView
            ((TextView) view.findViewById(R.id.textViewTitleValue)).setText(title);
            ((TextView) view.findViewById(R.id.textViewAuthorValue)).setText(author);
            ((TextView) view.findViewById(R.id.textViewYearValue)).setText(String.valueOf(year));
            ((TextView) view.findViewById(R.id.textViewSynopsisValue)).setText(synopsis);
        }

        return view;
    }
}
