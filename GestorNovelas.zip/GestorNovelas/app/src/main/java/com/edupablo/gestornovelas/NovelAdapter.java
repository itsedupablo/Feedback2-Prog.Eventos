package com.edupablo.gestornovelas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NovelAdapter extends RecyclerView.Adapter<NovelAdapter.NovelViewHolder> {

    private List<Novel> novels;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Novel novel);
    }

    public NovelAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setNovels(List<Novel> novels) {
        this.novels = novels;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NovelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.novel_item, parent, false);
        return new NovelViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NovelViewHolder holder, int position) {
        Novel novel = novels.get(position);

        // Configurar campos de texto
        holder.textViewTitle.setText(novel.getTitle());
        holder.textViewAuthor.setText(novel.getAuthor());
        holder.textViewDescription.setText(novel.getSynopsis());

        // Configurar el campo de ubicación
        if (novel.getLatitude() != 0 && novel.getLongitude() != 0) {
            holder.textViewLocation.setVisibility(View.VISIBLE);
            holder.textViewLocation.setText("Ubicación: " + novel.getLatitude() + ", " + novel.getLongitude());
        } else {
            holder.textViewLocation.setVisibility(View.GONE);
        }

        // Listener para clics
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(novel);
            }
        });
    }

    @Override
    public int getItemCount() {
        return novels == null ? 0 : novels.size();
    }

    public static class NovelViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewTitle;
        private final TextView textViewAuthor;
        private final TextView textViewDescription;
        private final TextView textViewLocation;

        public NovelViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewAuthor = itemView.findViewById(R.id.textViewAuthor);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            textViewLocation = itemView.findViewById(R.id.textViewLocation);  // Nuevo TextView para la ubicación
        }
    }
}
