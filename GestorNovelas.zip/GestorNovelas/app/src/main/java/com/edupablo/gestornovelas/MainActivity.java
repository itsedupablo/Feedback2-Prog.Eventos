package com.edupablo.gestornovelas;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class MainActivity extends AppCompatActivity {

    private Button buttonAddBook;
    private Button buttonViewFavorites;
    private Button buttonViewLocation;  // Botón para ver la ubicación actual del usuario
    private Button buttonViewNovelsMap; // Botón para ver todas las novelas en el mapa
    private RecyclerView recyclerView;
    private NovelViewModel novelViewModel;
    private NovelAdapter novelAdapter;
    private boolean showingFavorites = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar botones y RecyclerView
        buttonAddBook = findViewById(R.id.buttonAddBook);
        buttonViewFavorites = findViewById(R.id.buttonViewFavorites);
        buttonViewLocation = findViewById(R.id.buttonViewLocation);
        buttonViewNovelsMap = findViewById(R.id.buttonViewNovelsMap); // Inicializar botón
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        // Configurar el adaptador
        novelAdapter = new NovelAdapter(novel -> {
            // Acción al hacer clic en una novela
            if (novel.getLatitude() != 0 && novel.getLongitude() != 0) {
                Intent intent = new Intent(MainActivity.this, UbiActivity.class);
                intent.putExtra("latitud", novel.getLatitude());
                intent.putExtra("longitud", novel.getLongitude());
                intent.putExtra("nombre", novel.getTitle());
                startActivity(intent);
            } else {
                Toast.makeText(this, "No hay ubicación asociada a esta novela", Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(novelAdapter);

        // Configurar ViewModel
        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);

        // Observar todas las novelas
        novelViewModel.getAllNovels().observe(this, novels -> {
            if (!showingFavorites) {
                novelAdapter.setNovels(novels);
            }
        });

        // Botón para agregar una novela
        buttonAddBook.setOnClickListener(v -> showAddNovelDialog());

        // Botón para ver novelas favoritas
        buttonViewFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
            startActivity(intent);
        });

        // Botón para ver la ubicación del usuario
        buttonViewLocation.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UbiActivity.class);
            startActivity(intent);
        });

        // Botón para ver todas las novelas en el mapa
        buttonViewNovelsMap.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NovelsMapActivity.class);
            startActivity(intent);
        });
    }

    private void showAddNovelDialog() {
        // Crear diálogo para agregar una novela
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.agregar_novela_dialog, null);
        builder.setView(dialogView);

        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextAuthor = dialogView.findViewById(R.id.editTextAuthor);
        EditText editTextYear = dialogView.findViewById(R.id.editTextYear);
        EditText editTextSynopsis = dialogView.findViewById(R.id.editTextSynopsis);

        Button buttonCaptureLocation = dialogView.findViewById(R.id.buttonCaptureLocation); // Botón para capturar ubicación
        TextView textViewCapturedLocation = dialogView.findViewById(R.id.textViewCapturedLocation); // Mostrar la ubicación capturada

        final double[] capturedLatitude = {0.0};
        final double[] capturedLongitude = {0.0};

        // Configurar el botón para capturar ubicación
        buttonCaptureLocation.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                obtenerUbicacion(location -> {
                    capturedLatitude[0] = location.getLatitude();
                    capturedLongitude[0] = location.getLongitude();
                    textViewCapturedLocation.setText("Ubicación capturada: " +
                            capturedLatitude[0] + ", " + capturedLongitude[0]);
                    textViewCapturedLocation.setVisibility(View.VISIBLE);
                });
            }
        });

        builder.setTitle("Agregar novela")
                .setPositiveButton("Agregar", (dialog, which) -> {
                    // Recoger los datos introducidos por el usuario
                    String title = editTextTitle.getText().toString();
                    String author = editTextAuthor.getText().toString();
                    int year = Integer.parseInt(editTextYear.getText().toString());
                    String synopsis = editTextSynopsis.getText().toString();

                    // Crear una nueva novela con la ubicación capturada
                    Novel novel = new Novel(title, author, year, synopsis, false,
                            null, capturedLatitude[0], capturedLongitude[0]);
                    novelViewModel.insert(novel);

                    Toast.makeText(this, "Novela agregada", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void obtenerUbicacion(OnLocationCapturedListener listener) {
        Log.d("MainActivity", "Intentando obtener ubicación...");

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e("MainActivity", "Permisos de ubicación no concedidos.");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }

        FusedLocationProviderClient locationClient = LocationServices.getFusedLocationProviderClient(this);

        locationClient.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        Log.d("MainActivity", "Ubicación obtenida: " + location.getLatitude() + ", " + location.getLongitude());
                        listener.onLocationCaptured(location);
                    } else {
                        Log.e("MainActivity", "Ubicación no disponible.");
                        Toast.makeText(this, "No se pudo obtener la ubicación actual.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("MainActivity", "Error al obtener la ubicación: " + e.getMessage());
                    Toast.makeText(this, "Error al obtener la ubicación: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }



    // Interfaz para manejar la ubicación capturada
    interface OnLocationCapturedListener {
        void onLocationCaptured(Location location);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults); // Llamada al método base

        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permiso de ubicación concedido", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
        }
    }

}
