package com.edupablo.gestornovelas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class FavoritesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NovelAdapter novelAdapter;
    private NovelViewModel novelViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        recyclerView = findViewById(R.id.recyclerViewFavorites);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        // Configuramos el adaptador con el listener
        novelAdapter = new NovelAdapter(novel -> {
            // Acción al hacer clic en una novela favorita
            if (novel.getLatitude() != 0 && novel.getLongitude() != 0) {
                // Si tiene ubicación, mostrarla en el mapa
                Intent intent = new Intent(FavoritesActivity.this, UbiActivity.class);
                intent.putExtra("latitud", novel.getLatitude());
                intent.putExtra("longitud", novel.getLongitude());
                intent.putExtra("nombre", novel.getTitle());
                startActivity(intent);
            } else {
                // Si no tiene ubicación, mostrar un mensaje
                Toast.makeText(this, "No hay ubicación asociada a esta novela", Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(novelAdapter);

        // Configuración de ViewModel para observar solo las novelas favoritas
        novelViewModel = new ViewModelProvider(this).get(NovelViewModel.class);
        novelViewModel.getFavoriteNovels().observe(this, favorites -> {
            if (favorites != null && !favorites.isEmpty()) {
                novelAdapter.setNovels(favorites);  // Actualiza el adaptador con los favoritos
            } else {
                // En caso de que no haya favoritos, muestra un mensaje o realiza alguna acción
                Toast.makeText(this, "No hay novelas favoritas", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
